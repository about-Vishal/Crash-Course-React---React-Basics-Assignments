// src/components/Welcome1.jsx

import React from "react";

function Welcome1({ name }) {
  return (
    <div>
      <h1>Welcome, {name}!</h1>
    </div>
  );
}

export default Welcome1;
