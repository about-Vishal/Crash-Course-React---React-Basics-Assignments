// src/components/Greeting.jsx

import React from "react";

function Greeting({ message }) {
  return (
    <div>
      <h2>{/* complete the missing code */}</h2>
    </div>
  );
}

export default Greeting;
