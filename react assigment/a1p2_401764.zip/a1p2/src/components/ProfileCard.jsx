// src/components/ProfileCard.jsx

import React from "react";

function ProfileCard({ name, age, location }) {
  return (
    <div>
      <h3>{/* complete the missing code */}</h3>
      <p>Age: {/* complete the missing code */}</p>
      <p>Location: {/* complete the missing code */}</p>
    </div>
  );
}

export default ProfileCard;
