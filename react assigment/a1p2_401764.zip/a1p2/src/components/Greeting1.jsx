// src/components/Greeting1.jsx

import React from "react";

function Greeting1() {
  const name = "Aspiring Developer";
  return (
    <div>
      <h1>Hello, {name}!</h1>
    </div>
  );
}

export default Greeting1;
