// src/components/Welcome.jsx

import React from "react";

function Welcome() {
  const name = "React Developer";
  return (
    <div>
      <p>Welcome, {/* complete the missing code */}!</p>
    </div>
  );
}

export default Welcome;
