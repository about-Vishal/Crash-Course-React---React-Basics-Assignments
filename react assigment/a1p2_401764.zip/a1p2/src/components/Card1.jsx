// src/components/Card1.jsx

import React from "react";

function Card1({ children }) {
  return <div className="card">{children}</div>;
}

export default Card1;
